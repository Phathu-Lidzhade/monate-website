<?php
// view_menu.php - renders the menu items grid and the item-detail popup
?>
<section class="menu-section" id="menu-section">
  <?php foreach ($menuItems as $category => $items): ?>
    <h3><?= strtoupper(htmlspecialchars($category)) ?></h3>
    <div class="menu-grid">
      <?php foreach ($items as $item): ?>
        <div class="menu-card"
             data-id="<?= (int)$item['id'] ?>"
             data-name="<?= htmlspecialchars($item['name']) ?>"
             data-price="<?= number_format($item['price'], 2) ?>"
             data-description="<?= htmlspecialchars($item['description']) ?>"
             data-image="../admin/menu_item/<?= htmlspecialchars($item['image']) ?>">
          <img src="../admin/menu_item/<?= htmlspecialchars($item['image']) ?>" 
               alt="<?= htmlspecialchars($item['name']) ?>">
          <p class="item-name"><?= htmlspecialchars($item['name']) ?></p>
          <p class="item-price">R<?= number_format($item['price'], 2) ?></p>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endforeach; ?>
</section>

<!-- ITEM DETAIL POPUP -->
<div id="item-detail" class="item-detail hidden">
  <div class="detail-content">
    <button id="close-detail">✖</button>
    <div class="detail-left">
      <img id="detail-img" src="" alt="">
    </div>
    <div class="detail-right">
      <h2 id="detail-name"></h2>
      <p class="food-price">R<span id="detail-price"></span></p>
      <p id="detail-description"></p>

      <div class="sauce-selection">
        <label>Choose Sauce:</label>
        <div class="sauce-options">
          <button type="button" class="sauce-btn" data-sauce="HOT">HOT</button>
          <button type="button" class="sauce-btn" data-sauce="MILD">MILD</button>
          <button type="button" class="sauce-btn" data-sauce="BBQ">BBQ</button>
          <button type="button" class="sauce-btn" data-sauce="NO SAUCE">NO SAUCE</button>
        </div>
      </div>

      <div class="quantity">
        <button class="qty-btn" id="minus">-</button>
        <span id="qty">1</span>
        <button class="qty-btn" id="plus">+</button>
      </div>

      <form method="POST" action="add_to_cart.php" onsubmit="return validateSauceSelection()">
        <input type="hidden" name="id" id="detail-id">
        <input type="hidden" name="name" id="detail-name-input">
        <input type="hidden" name="price" id="detail-price-input">
        <input type="hidden" name="img" id="detail-img-input">
        <input type="hidden" name="qty" id="qtyInput" value="1">
        <input type="hidden" name="sauce" id="sauce-input">
        <button type="submit" class="add-cart">ADD TO CART</button>
      </form>
    </div>
  </div>
</div>
