<?php
// control_cart.php - prepares $cartItems, $totalItems, $totalPrice
if (session_status() === PHP_SESSION_NONE) session_start();

require_once __DIR__ . '/../../API/db.php';
require_once __DIR__ . '/model.php';

$branchLocation = "Thohoyandou";

// Ensure user is logged in
if (!isset($_SESSION["user_id"])) {
    header("Location: ../Sign in/index.php");
    exit;
}

$userId = $_SESSION["user_id"];

// Fetch cart items for this user & this branch
$result = getCartItemsForUserAndBranch($conn, $userId, $branchLocation);
$cartItems = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

$totalItems = 0;
$totalPrice = 0.0;
foreach ($cartItems as $item) {
    $totalItems += (int)$item["quantity"];
    $totalPrice += ((float)$item["price"]) * (int)$item["quantity"];
}
