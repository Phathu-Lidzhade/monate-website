<?php
// view_cart.php - displays cart table
?>
<main class="cart-page" style="padding:2rem;">
  <h1>Shopping Cart – Thohoyandou</h1>

  <?php if (empty($cartItems)): ?>
    <p>Your cart for <strong>Thohoyandou</strong> is empty. 
       <a href="Thohoyandou.php">Continue Shopping</a></p>
  <?php else: ?> 
    <table class="cart-table" style="width:100%; border-collapse:collapse; margin-bottom:2rem;">
      <tr>
        <th>Image</th>
        <th>Item</th>
        <th>Sauce</th>
        <th>Price</th>
        <th>Quantity</th>
        <th>Subtotal</th>
        <th>Action</th>
      </tr>
      <?php foreach ($cartItems as $item): ?>
        <tr>
          <td style="text-align:center;"><img src="<?= htmlspecialchars($item['image']) ?>" alt="<?= htmlspecialchars($item['name']) ?>" style="width:60px;height:60px;object-fit:cover;border-radius:8px;"></td>
          <td style="text-align:center;"><?= htmlspecialchars($item['name']) ?></td>
          <td style="text-align:center;"><?= htmlspecialchars($item['sauce']) ?></td>
          <td style="text-align:center;">R<?= number_format($item['price'], 2) ?></td>
          <td style="text-align:center;"><?= (int)$item['quantity'] ?></td>
          <td style="text-align:center;">R<?= number_format($item['price'] * $item['quantity'], 2) ?></td>
          <td style="text-align:center;">
            <form method="POST" action="remove_from_cart.php" style="display:inline;">
              <input type="hidden" name="cart_id" value="<?= (int)$item['id'] ?>">
              <button type="submit" class="remove-btn" style="background:#ed1b26;color:white;padding:.3rem .6rem;border:none;border-radius:4px;cursor:pointer;">Remove</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
    </table>

    <div class="summary" style="text-align:right;border-top:2px solid #000;padding-top:1rem;">
      <p><strong>Total Items:</strong> <?= (int)$totalItems ?></p>
      <p><strong>Total Price:</strong> R<?= number_format($totalPrice, 2) ?></p>
      <a href="checkout.php?branch=Thohoyandou">
        <button class="checkout-btn" style="margin-top:1rem;background:#ed1b26;color:#fff;padding:.8rem 2rem;border:none;font-size:1rem;border-radius:25px;cursor:pointer;">Proceed to Checkout</button>
      </a>
    </div>
  <?php endif; ?>
</main>
