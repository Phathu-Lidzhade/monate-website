<?php
// model.php - DB helper functions used by menu and cart controllers

function getMenuItemsByBranch($conn, $branchLocation) {
    $stmt = $conn->prepare("SELECT id, name, price, description, category, image, branch_location 
                            FROM MenuItems 
                            WHERE branch_location = ?");
    if ($stmt === false) return false;
    $stmt->bind_param("s", $branchLocation);
    $stmt->execute();
    return $stmt->get_result();
}

function getCartCountForUserAndBranch($conn, $userId, $branchLocation) {
    $cartStmt = $conn->prepare("
        SELECT SUM(quantity) AS total
        FROM Cart
        WHERE user_id = ? AND branch_location = ?
    ");
    if ($cartStmt === false) return 0;
    $cartStmt->bind_param("is", $userId, $branchLocation);
    $cartStmt->execute();
    $cartResult = $cartStmt->get_result();
    $row = $cartResult->fetch_assoc();
    return (int)($row["total"] ?? 0);
}

function getCartItemsForUserAndBranch($conn, $userId, $branchLocation) {
    $stmt = $conn->prepare("
        SELECT id, item_id, name, price, quantity, sauce, image
        FROM Cart
        WHERE user_id = ? AND branch_location = ?
    ");
    if ($stmt === false) return false;
    $stmt->bind_param("is", $userId, $branchLocation);
    $stmt->execute();
    return $stmt->get_result();
}
