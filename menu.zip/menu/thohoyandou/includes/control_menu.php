<?php
// controller for Thohoyandou page
if (session_status() === PHP_SESSION_NONE) session_start();

// require DB and model
require_once __DIR__ . '/../../API/db.php';
require_once __DIR__ . '/model.php';

// Force branch
$branchLocation = "Thohoyandou";

// Fetch menu items for this branch (grouped by category)
$result = getMenuItemsByBranch($conn, $branchLocation);

// Group by category
$menuItems = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $menuItems[$row["category"]][] = $row;
    }
}

// Cart count for this user & branch
$cartCount = 0;
if (isset($_SESSION["user_id"])) {
    $userId = $_SESSION["user_id"];
    $cartCount = getCartCountForUserAndBranch($conn, $userId, $branchLocation);
}
