<?php
require_once __DIR__ . '/includes/control_cart.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Your Cart - Thohoyandou</title>
  <link rel="stylesheet" href="assets/css/menu.css" />
</head>
<body>
  <!-- HEADER -->
  <header class="top-header">
    <div class="logo">
      <img src="img/logo 2.png" alt="Monate Logo">
    </div>
    <nav class="nav-links">
      <a href="../HOME/index.php">HOME</a>
      <a href="../About Us/index.php">ABOUT US</a>
    </nav>
    <div class="account-cart">
      <a href="../Sign in/index.php" class="account">
        <img src="img/profile.png" alt="Account">
        <span>
          <?php if (isset($_SESSION["username"])): ?>
            Hi, <?= htmlspecialchars($_SESSION["username"]); ?>
          <?php else: ?>
            ACCOUNT
          <?php endif; ?>
        </span>
      </a>
      <div class="divider"></div>
      <a href="cart.php" class="cart">
        <img src="img/shopping cart.png" alt="Cart">
        <?php if ($totalItems > 0): ?>
          <span class="cart-badge"><?= (int)$totalItems ?></span>
        <?php endif; ?>
      </a>
    </div>
  </header>

  <?php require_once __DIR__ . '/includes/view_cart.php'; ?>

</body>
</html>
