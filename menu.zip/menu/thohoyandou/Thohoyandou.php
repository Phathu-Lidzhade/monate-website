<?php
// Thohoyandou.php - entry page (runs controller, then renders view)
require_once __DIR__ . '/includes/control_menu.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Monate Menu - Thohoyandou</title>
  <link rel="stylesheet" href="assets/css/menu.css" />
</head>
<body>

  <!-- HEADER -->
  <header class="top-header">
    <div class="logo">
      <img src="img/logo 2.png" alt="Monate Logo">
    </div>
    <nav class="nav-links">
      <a href="../HOME/index.php">HOME</a>
      <a href="../About Us/index.php">ABOUT US</a>
    </nav>
    <div class="account-cart">
      <!-- Account -->
      <a href="../Sign in/index.php" class="account">
        <img src="img/profile.png" alt="Account">
        <span>
          <?php if (isset($_SESSION["username"])): ?>
            Hi, <?= htmlspecialchars($_SESSION["username"]); ?>
          <?php else: ?>
            ACCOUNT
          <?php endif; ?>
        </span>
      </a>
      <div class="divider"></div>

      <!-- Cart -->
      <a href="<?php echo isset($_SESSION["user_id"]) ? 'cart.php' : '../Sign in/index.php'; ?>" class="cart">
          <img src="img/shopping cart.png" alt="Cart">
          <?php if ($cartCount > 0): ?>
            <span class="cart-badge"><?= (int)$cartCount ?></span>
          <?php endif; ?>
      </a>
    </div>
  </header>

  <!-- LOCATION BAR -->
  <div class="location-bar">
    <a href="Thohoyandou.php" class="location-item active">
      <img src="img/location.png" alt="Location">
      <span>THOHOYANDOU</span>
    </a>
  </div>

  <!-- MAIN MENU -->
  <main class="content">
    <!-- SIDE MENU (Categories) -->
    <aside class="side-menu">
      <h2>MENU</h2>
      <ul>
        <?php foreach ($menuItems as $category => $items): ?>
          <li data-category="<?= strtolower(htmlspecialchars($category)) ?>"><?= strtoupper(htmlspecialchars($category)) ?></li>
        <?php endforeach; ?>
      </ul>
    </aside>

    <!-- MENU ITEMS (view snippet) -->
    <?php require_once __DIR__ . '/includes/view_menu.php'; ?>
  </main>

  <!-- ITEM DETAIL POPUP (the HTML used by JS; kept in view_menu.php) -->
  <?php /* view_menu.php contains the popup markup */ ?>

  <script src="assets/js/menu.js"></script>
</body>
</html>
