// menu.js - behavior for menu cards, popup, sauce selection, qty
document.addEventListener("DOMContentLoaded", () => {
  const sideMenuItems = document.querySelectorAll(".side-menu li");
  const sections = document.querySelectorAll(".menu-section h3, .menu-grid");

  // Filter by category
  sideMenuItems.forEach(item => {
    item.addEventListener("click", () => {
      const category = item.getAttribute("data-category").toUpperCase();

      sections.forEach(section => {
        if (section.tagName === "H3") {
          section.style.display = (section.textContent === category) ? "block" : "none";
        } else {
          section.style.display = (section.previousElementSibling.textContent === category) ? "grid" : "none";
        }
      });

      sideMenuItems.forEach(i => i.classList.remove("active"));
      item.classList.add("active");
    });
  });

  // Default: show first category
  if (sideMenuItems.length > 0) sideMenuItems[0].click();

  // Popup logic
  const detail = document.getElementById("item-detail");
  const closeBtn = document.getElementById("close-detail");

  const detailId = document.getElementById("detail-id");
  const detailName = document.getElementById("detail-name");
  const detailPrice = document.getElementById("detail-price");
  const detailDesc = document.getElementById("detail-description");
  const detailImg = document.getElementById("detail-img");

  const inputName = document.getElementById("detail-name-input");
  const inputPrice = document.getElementById("detail-price-input");
  const inputImg = document.getElementById("detail-img-input");

  let qty = 1;
  const qtySpan = document.getElementById("qty");
  const qtyInput = document.getElementById("qtyInput");

  document.getElementById("plus").addEventListener("click", () => {
    if (qty < 10) qty++;
    qtySpan.textContent = qty;
    qtyInput.value = qty;
  });

  document.getElementById("minus").addEventListener("click", () => {
    if (qty > 1) qty--;
    qtySpan.textContent = qty;
    qtyInput.value = qty;
  });

  // Handle clicks on menu cards
  document.querySelectorAll(".menu-card").forEach(card => {
    card.addEventListener("click", () => {
      qty = 1;
      qtySpan.textContent = qty;
      qtyInput.value = qty;

      // Fill details
      detailId.value = card.dataset.id;
      detailName.textContent = card.dataset.name;
      detailPrice.textContent = card.dataset.price;
      detailDesc.textContent = card.dataset.description;
      detailImg.src = card.dataset.image;

      inputName.value = card.dataset.name;
      inputPrice.value = card.dataset.price;
      inputImg.value = card.dataset.image;

      // Update URL
      const newUrl = window.location.pathname + "?id=" + card.dataset.id;
      window.history.pushState({id: card.dataset.id}, "", newUrl);

      detail.classList.remove("hidden");

      // Reset sauce buttons
      sauceButtons.forEach(btn => btn.classList.remove("active"));
      sauceInput.value = "";
    });
  });

  // Close popup
  closeBtn.addEventListener("click", () => {
    detail.classList.add("hidden");
    window.history.pushState({}, "", window.location.pathname);
  });

  // Auto-open if ?id= is in URL
  const urlParams = new URLSearchParams(window.location.search);
  const selectedId = urlParams.get("id");
  if (selectedId) {
    const card = document.querySelector(`.menu-card[data-id='${selectedId}']`);
    if (card) card.click();
  }

  const sauceButtons = document.querySelectorAll(".sauce-btn");
  const sauceInput = document.getElementById("sauce-input");

  // Handle sauce selection
  sauceButtons.forEach(button => {
    button.addEventListener("click", () => {
      sauceButtons.forEach(btn => btn.classList.remove("active"));
      button.classList.add("active");
      sauceInput.value = button.dataset.sauce;
    });
  });

  // Validate sauce selection before form submission
  window.validateSauceSelection = () => {
    if (!sauceInput.value) {
      alert("Please select a sauce before adding to cart.");
      return false;
    }
    return true;
  };
});
