<?php
// add_to_cart.php - handler for add to cart POST
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../../API/db.php';

// Ensure user logged in
$userId = $_SESSION["user_id"] ?? null;
if (!$userId) {
    header("Location: ../Sign in/index.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $itemId = $_POST["id"];
    $itemName = $_POST["name"];
    $itemPrice = $_POST["price"];
    $itemQty = $_POST["qty"];
    $itemSauce = $_POST["sauce"];
    $itemImg = $_POST["img"];
    $branchLocation = "Thohoyandou"; // keep same forced branch as original

    $stmt = $conn->prepare("
        INSERT INTO Cart (user_id, item_id, name, price, quantity, sauce, image, branch_location) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity)
    ");
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }
    $stmt->bind_param("iisdisss", $userId, $itemId, $itemName, $itemPrice, $itemQty, $itemSauce, $itemImg, $branchLocation);
    if (!$stmt->execute()) {
        die("Execute failed: " . $stmt->error);
    }

    header("Location: Thohoyandou.php?id=" . urlencode($itemId));
    exit;
}
