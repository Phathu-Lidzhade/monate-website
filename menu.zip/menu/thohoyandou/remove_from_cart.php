<?php
// remove_from_cart.php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../../API/db.php';

if (!isset($_SESSION["user_id"])) {
    header("Location: ../Sign in/index.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["cart_id"])) {
    $cartId = intval($_POST["cart_id"]);
    $userId = $_SESSION["user_id"];

    $stmt = $conn->prepare("DELETE FROM Cart WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $cartId, $userId);

    if ($stmt->execute()) {
        header("Location: cart.php");
        exit;
    } else {
        echo "Error removing item from cart.";
    }
} else {
    header("Location: cart.php");
    exit;
}
